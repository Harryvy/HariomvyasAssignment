package com.smartdatasolutions.test.impl;

import com.smartdatasolutions.test.Member;
import com.smartdatasolutions.test.MemberExporter;
import com.smartdatasolutions.test.MemberFileConverter;
import com.smartdatasolutions.test.MemberImporter;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main extends MemberFileConverter {

	@Override
	protected MemberExporter getMemberExporter( ) {
		// TODO
		
		return new MemberExporterImpl();
	}

	@Override
	protected MemberImporter getMemberImporter( ) {
		// TODO
		return new MemberImporterImpl();
	}

	@Override
    protected List<Member> getNonDuplicateMembers(List<Member> membersFromFile) {
        Set<String> uniqueIds = new HashSet<>();
        List<Member> nonDuplicateMembers = new ArrayList<>();

        for (Member member : membersFromFile) {
            // Check if the id is already encountered
            if (uniqueIds.add(member.getId())) {
                nonDuplicateMembers.add(member);
            }
        }

        return nonDuplicateMembers;
    }



@Override
protected Map<String, List<Member>> splitMembersByState(List<Member> validMembers) {
    Map<String, List<Member>> membersByState = new HashMap<>();

    for (Member member : validMembers) {
        String state = member.getState();

        // If the state is not already in the map, add it with an empty list
        membersByState.putIfAbsent(state, new ArrayList<>());

        // Add the member to the list corresponding to its state
        membersByState.get(state).add(member);
    }

    return membersByState;
}

	public static void main( String[] args ) throws Exception {
		
		Main m = new Main();
		//input file path i.e. "Members.txt"
		File file = new File("D:\\study\\practice\\springboot\\MemberFileConverter\\src\\Members.txt");
		//output file path(folder) "outputcsv"
		m.convert(file, "D:\\study\\practice\\springboot\\MemberFileConverter\\src\\outputcsv", "outputFile.csv");
		
	}

}
